﻿public class Estudiante
{
    public int Id { get; set; }
    public required string CURP { get; set; }
    public required string Telefono { get; set; }
    public required string Email { get; set; }
    public required string Carrera { get; set; }
    public required bool Becado { get; set; }
    public required string Modalidad { get; set; }
    public required string Nombres { get; set; }
    public required string Apellidos { get; set; }
    public required string Direccion { get; set; }

    // Opcionales
    public string? Descripcion { get; set; }
    public bool? TieneMascotas { get; set; }
    public string? Mascotas { get; set; }
    public string? HorarioComida { get; set; }
}
